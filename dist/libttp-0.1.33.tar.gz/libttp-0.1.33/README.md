# libttp

The libttp are the python libraries for the BrightEyes-Time Tagging Module.

Documentation and example at https://brighteyes-ttm.readthedocs.io 
and the source code of the BrightEyes-TTM project on the GitHub repository https://github.com/VicidominiLab/BrightEyes-TTM .

### Installation

```
pip install libttp
```
